function addcookie(name, value, expireHours) {
    var cookieString = name + "=" + escape(value) + "; path=/";
    //判断是否设置过期时间
    if (expireHours > 0) {
        var date = new Date();
        date.setTime(date.getTime + expireHours * 3600 * 1000);
        cookieString = cookieString + "; expire=" + date.toGMTString();
    }
    document.cookie = cookieString;
}

function getcookie(name) {
    var strcookie = document.cookie;
    var arrcookie = strcookie.split("; ");
    for (var i = 0; i < arrcookie.length; i++) {
        var arr = arrcookie[i].split("=");
        if (arr[0] == name)return decodeURIComponent(arr[1]); //增加对特殊字符的解析
    }
    return "";
}

function delCookie(name) {//删除cookie
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = getcookie(name);
    if (cval != null) document.cookie = name + "=" + cval + "; path=/;expires=" + exp.toGMTString();
}

function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)
        return unescape(r[2]);
    return null;
}
var mAccessCode;
var appid = "wxbf46ad8a4193878a";
var secret = "99311d2820ea40b67bf25bce1286581b";
function getCode() {
    $(function () {
        var fromurl = location.href;
        var access_code = GetQueryString('code');
        if (access_code == "" || access_code == null) {
            var url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' + appid + '&redirect_uri=' + encodeURIComponent(fromurl) + '&response_type=code&scope=snsapi_base&state=STATE%23wechat_redirect&connect_redirect=1#wechat_redirect';
            location.href = url;
        } else {
            mAccessCode = access_code;
        }
    })
}
// function getOpenId(access_code, amount) {//这种方法需要后台，可以将secret放在后台不至于暴露
//     $(function () {
//         $.get("/getOpenID?access_code=" + access_code + "&amount=" + amount, function (data, status) {
//             alert("getOpenID结果=" + data);
//             var obj = eval('(' + data + ')');
//             wxPay(obj.appId, obj.timeStamp, obj.nonceStr, obj.package, obj.signType, obj.paySign);
//         });
//     })
// }
function getOpenId(access_code, amount) {//这种方法不需要后台，直接前台获得openid
    $(function () {
        alert("进入了getOpenID" + access_code +"--"+ amount);
        // 调用后台接口去获得openId,获得了openId之后调用prepay方法
        // $.get("https://api.weixin.qq.com/sns/oauth2/access_token?appid=" + appid + "&secret=" + secret + "&code=" + access_code + "&grant_type=authorization_code", function (data, status) {
        //     alert("openId=" + data);
        //     var obj = eval('(' + data + ')');
        //     var openId = obj.openid;
        //     prepay(openId, amount);
        // });
    })
}
function prepay(openid, amount) {
    $.get("请求银行/自己接口，传入openid,获得prepayId什么的", function (data, status) {
        var obj = eval('(' + data + ')');
        wxPay(obj.appId, obj.timeStamp, obj.nonceStr, obj.package, obj.signType, obj.paySign);
    });
}
function wxPay(appId, timeStamp, nonceStr, package, signType, paySign) {
    function onBridgeReady() {
        WeixinJSBridge.invoke(
            'getBrandWCPayRequest', {
                "appId": appId,     //公众号名称，由商户传入
                "timeStamp": timeStamp,         //时间戳，自1970年以来的秒数
                "nonceStr": nonceStr, //随机串
                "package": package,
                "signType": signType,         //微信签名方式：
                "paySign": paySign //微信签名
            },
            function (res) {
                if (res.err_msg == "get_brand_wcpay_request:ok") {
                }     // 使用以上方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。
            }
        );
    }

    if (typeof WeixinJSBridge == "undefined") {
        if (document.addEventListener) {
            document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
        } else if (document.attachEvent) {
            document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
            document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
    } else {
        onBridgeReady();
    }
}
function is_weixin() {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
    } else {
        return false;
    }
}
var isWeixin = is_weixin();
function is_alipay() {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/Alipay/i) == "alipay") {
        return true;
    } else {
        return false;
    }
}
var isAlipay = is_alipay();
var result = 0;
if (isAlipay) {
    result = 1;
    // getBuyerId();
} else if (isWeixin) {
    result = 2;
    // getOpenId();
    getCode();
}
$(document).ready(function () {
    $("#pay").click(function () {
        var amount = $("#amount").val();
        alert(amount);
        switch (result) {
            case 1:
                //支付宝
                getBuyerId();
                break;
            case 2:
                //微信
                getOpenId(mAccessCode, amount);
                break;
            default:
                alert("请在微信或支付宝中打开");
                break;
        }
    });
});
function getBuyerId() {
    $(function () {
        var fromUrl = location.href;
        var auth_code = GetQueryString('auth_code');
        if (auth_code == "" || auth_code == null) {
            var url = "http://hfyh.zephpay.com/pay/dist/index.html?returl=" + encodeURIComponent(fromUrl);
            location.href = url;
        } else {
            alert("auth_code = " + auth_code);
        }
    });
}